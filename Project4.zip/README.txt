woese002
- There are no assumptions that are made other than the maze being at least a 2 by 2 matrix.
- There are no known bugs or defects in the program.