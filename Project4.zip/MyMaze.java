// Tenzin Woeser:
// woese002:

import java.util.Random;

public class MyMaze{
    Cell[][] maze;

    public MyMaze(int rows, int cols) {
        maze = new Cell[rows][cols];//creates an instance with the specified rows and cols
        for (int i = 0; i<rows; i++){
            for (int j = 0; j<cols; j++){
                maze[i][j] = new Cell();//makes sure every cell does not contain null
            }
        }
    }
    /* TODO: Create a new maze using the algorithm found in the writeup. */
    public static MyMaze makeMaze(int rows, int cols) {
        MyMaze l = new MyMaze(rows,cols);
        Random rand = new Random();
        Stack1Gen<int[]> stack = new Stack1Gen<>();
        stack.push(new int[] {0,0});//pushing the first item into the stack
        l.maze[0][0].setVisited(true);
        while (!stack.isEmpty()){//goes on until the stack is empty
            int[] a = stack.top();
            if(a[0]==0 && a[1]==0){//checking upper left corner
                if(!l.maze[0][1].getVisited() && !l.maze[1][0].getVisited()) {
                    int x = rand.nextInt(2);
                    if (x == 0) {
                        stack.push(new int[]{0, 1});
                        l.maze[0][1].setVisited(true);
                        l.maze[0][0].setRight(false);
                    } else {
                        stack.push(new int[]{1, 0});
                        l.maze[1][0].setVisited(true);
                        l.maze[0][0].setBottom(false);
                    }
                }
                else if(!l.maze[0][1].getVisited()){
                    stack.push(new int[]{0, 1});
                    l.maze[0][1].setVisited(true);
                    l.maze[0][0].setRight(false);
                }
                else if (!l.maze[1][0].getVisited()){
                    stack.push(new int[]{1, 0});
                    l.maze[1][0].setVisited(true);
                    l.maze[0][0].setBottom(false);
                }
                else{
                    stack.pop();
                }
            }
            else if(a[0]==0 && a[1]==cols-1){//checking for upper right corner
                if(!l.maze[0][cols-2].getVisited() && !l.maze[1][cols-1].getVisited()){
                    int x = rand.nextInt(2);
                    if (x == 0){
                        stack.push(new int[]{0, cols-2});
                        l.maze[0][cols-2].setVisited(true);
                        l.maze[0][cols-2].setRight(false);
                    } else {
                        stack.push(new int[]{1, cols-1});
                        l.maze[1][cols-1].setVisited(true);
                        l.maze[0][cols-1].setBottom(false);
                    }
                }
                else if(!l.maze[0][cols-2].getVisited()){
                    stack.push(new int[]{0, cols-2});
                    l.maze[0][cols-2].setVisited(true);
                    l.maze[0][cols-2].setRight(false);
                }
                else if (!l.maze[1][cols-1].getVisited()){
                    stack.push(new int[]{1, cols-1});
                    l.maze[1][cols-1].setVisited(true);
                    l.maze[0][cols-1].setBottom(false);
                }
                else{
                    stack.pop();
                }
            }
            else if(a[0]==rows-1 && a[1]==0){//checking for lower left corner
                if(!l.maze[rows-1][1].getVisited() && !l.maze[rows-2][0].getVisited()){
                    int x = rand.nextInt(2);
                    if (x == 0){
                        stack.push(new int[]{rows-1, 1});
                        l.maze[rows-1][1].setVisited(true);
                        l.maze[rows-1][0].setRight(false);
                    } else {
                        stack.push(new int[]{rows-2, 0});
                        l.maze[rows-2][0].setVisited(true);
                        l.maze[rows-2][0].setBottom(false);
                    }
                }
                else if(!l.maze[rows-1][1].getVisited()){
                    stack.push(new int[]{rows-1, 1});
                    l.maze[rows-1][1].setVisited(true);
                    l.maze[rows-1][0].setRight(false);
                }
                else if(!l.maze[rows-2][0].getVisited()){
                    stack.push(new int[]{rows-2, 0});
                    l.maze[rows-2][0].setVisited(true);
                    l.maze[rows-2][0].setBottom(false);
                }
                else{
                    stack.pop();
                }
            }
            else if(a[0] == rows-1 && a[1] == cols-1){//checking for lower right corner
                if(!l.maze[rows-1][cols-2].getVisited() && !l.maze[rows-2][cols-1].getVisited()){
                    int x = rand.nextInt(2);
                    if (x == 0){
                        stack.push(new int[]{rows-1, cols-2});
                        l.maze[rows-1][cols-2].setVisited(true);
                        l.maze[rows-1][cols-2].setRight(false);
                    } else {
                        stack.push(new int[]{rows-2, cols-1});
                        l.maze[rows-2][cols-1].setVisited(true);
                        l.maze[rows-2][cols-1].setBottom(false);
                    }
                }
                else if(!l.maze[rows-1][cols-2].getVisited()){
                    stack.push(new int[]{rows-1, cols-2});
                    l.maze[rows-1][cols-2].setVisited(true);
                    l.maze[rows-1][cols-2].setRight(false);
                }
                else if(!l.maze[rows-2][cols-1].getVisited()){
                    stack.push(new int[]{rows-2, cols-1});
                    l.maze[rows-2][cols-1].setVisited(true);
                    l.maze[rows-2][cols-1].setBottom(false);
                }
                else{
                    stack.pop();
                }
            }
            else if(a[0] == 0){//checking for top row
                if(!l.maze[0][a[1]-1].getVisited() && !l.maze[0][a[1]+1].getVisited() && !l.maze[1][a[1]].getVisited()){
                    int x = rand.nextInt(3);
                    if (x == 0){
                        stack.push(new int[]{0, a[1]-1});
                        l.maze[0][a[1]-1].setVisited(true);
                        l.maze[0][a[1]-1].setRight(false);
                    }
                    else if(x == 1){
                        stack.push(new int[]{0, a[1]+1});
                        l.maze[0][a[1]+1].setVisited(true);
                        l.maze[0][a[1]].setRight(false);
                    }
                    else{
                        stack.push(new int[]{1, a[1]});
                        l.maze[1][a[1]].setVisited(true);
                        l.maze[0][a[1]].setBottom(false);
                    }
                }
                else if(!l.maze[0][a[1]-1].getVisited() && !l.maze[0][a[1]+1].getVisited()){
                    int x = rand.nextInt(2);
                    if (x == 0){
                        stack.push(new int[]{0, a[1]-1});
                        l.maze[0][a[1]-1].setVisited(true);
                        l.maze[0][a[1]-1].setRight(false);
                    }
                    else{
                        stack.push(new int[]{0, a[1]+1});
                        l.maze[0][a[1]+1].setVisited(true);
                        l.maze[0][a[1]].setRight(false);
                    }
                }
                else if(!l.maze[0][a[1]-1].getVisited() && !l.maze[1][a[1]].getVisited()){
                    int x = rand.nextInt(2);
                    if (x == 0){
                        stack.push(new int[]{0, a[1]-1});
                        l.maze[0][a[1]-1].setVisited(true);
                        l.maze[0][a[1]-1].setRight(false);
                    }
                    else{
                        stack.push(new int[]{1, a[1]});
                        l.maze[1][a[1]].setVisited(true);
                        l.maze[0][a[1]].setBottom(false);
                    }
                }
                else if(!l.maze[0][a[1]+1].getVisited() && !l.maze[1][a[1]].getVisited()){
                    int x = rand.nextInt(2);
                    if (x == 0){
                        stack.push(new int[]{0, a[1]+1});
                        l.maze[0][a[1]+1].setVisited(true);
                        l.maze[0][a[1]].setRight(false);
                    }
                    else{
                        stack.push(new int[]{1, a[1]});
                        l.maze[1][a[1]].setVisited(true);
                        l.maze[0][a[1]].setBottom(false);
                    }
                }
                else if(!l.maze[0][a[1]-1].getVisited()){
                    stack.push(new int[]{0, a[1]-1});
                    l.maze[0][a[1]-1].setVisited(true);
                    l.maze[0][a[1]-1].setRight(false);
                }
                else if(!l.maze[0][a[1]+1].getVisited()){
                    stack.push(new int[]{0, a[1]+1});
                    l.maze[0][a[1]+1].setVisited(true);
                    l.maze[0][a[1]].setRight(false);
                }
                else if(!l.maze[1][a[1]].getVisited()){
                    stack.push(new int[]{1, a[1]});
                    l.maze[1][a[1]].setVisited(true);
                    l.maze[0][a[1]].setBottom(false);
                }
                else{
                    stack.pop();
                }
            }
            else if(a[1] == 0){//checking for left column
                if(!l.maze[a[0]-1][0].getVisited() && !l.maze[a[0]][1].getVisited() && !l.maze[a[0]+1][0].getVisited()){
                    int x = rand.nextInt(3);
                    if(x == 0){
                        stack.push(new int[]{a[0]-1, 0});
                        l.maze[a[0]-1][0].setVisited(true);
                        l.maze[a[0]-1][0].setBottom(false);
                    }
                    else if(x == 1){
                        stack.push(new int[]{a[0], 1});
                        l.maze[a[0]][1].setVisited(true);
                        l.maze[a[0]][0].setRight(false);
                    }
                    else{
                        stack.push(new int[]{a[0]+1, 0});
                        l.maze[a[0]+1][0].setVisited(true);
                        l.maze[a[0]][0].setBottom(false);
                    }
                }
                else if(!l.maze[a[0]-1][0].getVisited() && !l.maze[a[0]][1].getVisited()){
                    int x = rand.nextInt(2);
                    if (x == 0){
                        stack.push(new int[]{a[0]-1, 0});
                        l.maze[a[0]-1][0].setVisited(true);
                        l.maze[a[0]-1][0].setBottom(false);
                    }
                    else{
                        stack.push(new int[]{a[0], 1});
                        l.maze[a[0]][1].setVisited(true);
                        l.maze[a[0]][0].setRight(false);
                    }
                }
                else if(!l.maze[a[0]-1][0].getVisited() && !l.maze[a[0]+1][0].getVisited()){
                    int x = rand.nextInt(2);
                    if (x == 0){
                        stack.push(new int[]{a[0]-1, 0});
                        l.maze[a[0]-1][0].setVisited(true);
                        l.maze[a[0]-1][0].setBottom(false);
                    }
                    else{
                        stack.push(new int[]{a[0]+1, 0});
                        l.maze[a[0]+1][0].setVisited(true);
                        l.maze[a[0]][0].setBottom(false);
                    }
                }
                else if(!l.maze[a[0]][1].getVisited() && !l.maze[a[0]+1][0].getVisited()){
                    int x = rand.nextInt(2);
                    if (x == 0){
                        stack.push(new int[]{a[0], 1});
                        l.maze[a[0]][1].setVisited(true);
                        l.maze[a[0]][0].setRight(false);
                    }
                    else{
                        stack.push(new int[]{a[0]+1, 0});
                        l.maze[a[0]+1][0].setVisited(true);
                        l.maze[a[0]][0].setBottom(false);
                    }
                }
                else if(!l.maze[a[0]-1][0].getVisited()){
                    stack.push(new int[]{a[0]-1, 0});
                    l.maze[a[0]-1][0].setVisited(true);
                    l.maze[a[0]-1][0].setBottom(false);
                }
                else if(!l.maze[a[0]][1].getVisited()){
                    stack.push(new int[]{a[0], 1});
                    l.maze[a[0]][1].setVisited(true);
                    l.maze[a[0]][0].setRight(false);
                }
                else if(!l.maze[a[0]+1][0].getVisited()){
                    stack.push(new int[]{a[0]+1, 0});
                    l.maze[a[0]+1][0].setVisited(true);
                    l.maze[a[0]][0].setBottom(false);
                }
                else{
                    stack.pop();
                }
            }
            else if(a[1] == cols-1){//checking for right column
                if (!l.maze[a[0]-1][cols-1].getVisited() && !l.maze[a[0]][cols-2].getVisited() && !l.maze[a[0]+1][cols-1].getVisited()){
                    int x = rand.nextInt(3);
                    if (x == 0){
                        stack.push(new int[]{a[0]-1, cols-1});
                        l.maze[a[0]-1][cols-1].setVisited(true);
                        l.maze[a[0]-1][cols-1].setBottom(false);
                    }
                    else if(x == 1){
                        stack.push(new int[]{a[0], cols-2});
                        l.maze[a[0]][cols-2].setVisited(true);
                        l.maze[a[0]][cols-2].setRight(false);
                    }
                    else{
                        stack.push(new int[]{a[0]+1, cols-1});
                        l.maze[a[0]+1][cols-1].setVisited(true);
                        l.maze[a[0]][cols-1].setBottom(false);
                    }
                }
                else if(!l.maze[a[0]-1][cols-1].getVisited() && !l.maze[a[0]][cols-2].getVisited()){
                    int x = rand.nextInt(2);
                    if(x == 0){
                        stack.push(new int[]{a[0]-1, cols-1});
                        l.maze[a[0]-1][cols-1].setVisited(true);
                        l.maze[a[0]-1][cols-1].setBottom(false);
                    }
                    else{
                        stack.push(new int[]{a[0], cols-2});
                        l.maze[a[0]][cols-2].setVisited(true);
                        l.maze[a[0]][cols-2].setRight(false);
                    }
                }
                else if(!l.maze[a[0]-1][cols-1].getVisited() && !l.maze[a[0]+1][cols-1].getVisited()){
                    int x = rand.nextInt(2);
                    if(x == 0){
                        stack.push(new int[]{a[0]-1, cols-1});
                        l.maze[a[0]-1][cols-1].setVisited(true);
                        l.maze[a[0]-1][cols-1].setBottom(false);
                    }
                    else{
                        stack.push(new int[]{a[0]+1, cols-1});
                        l.maze[a[0]+1][cols-1].setVisited(true);
                        l.maze[a[0]][cols-1].setBottom(false);
                    }
                }
                else if(!l.maze[a[0]][cols-2].getVisited() && !l.maze[a[0]+1][cols-1].getVisited()){
                    int x = rand.nextInt(2);
                    if(x == 0){
                        stack.push(new int[]{a[0], cols-2});
                        l.maze[a[0]][cols-2].setVisited(true);
                        l.maze[a[0]][cols-2].setRight(false);
                    }
                    else{
                        stack.push(new int[]{a[0]+1, cols-1});
                        l.maze[a[0]+1][cols-1].setVisited(true);
                        l.maze[a[0]][cols-1].setBottom(false);
                    }
                }
                else if(!l.maze[a[0]-1][cols-1].getVisited()){
                    stack.push(new int[]{a[0]-1, cols-1});
                    l.maze[a[0]-1][cols-1].setVisited(true);
                    l.maze[a[0]-1][cols-1].setBottom(false);
                }
                else if(!l.maze[a[0]][cols-2].getVisited()){
                    stack.push(new int[]{a[0], cols-2});
                    l.maze[a[0]][cols-2].setVisited(true);
                    l.maze[a[0]][cols-2].setRight(false);
                }
                else if(!l.maze[a[0]+1][cols-1].getVisited()){
                    stack.push(new int[]{a[0]+1, cols-1});
                    l.maze[a[0]+1][cols-1].setVisited(true);
                    l.maze[a[0]][cols-1].setBottom(false);
                }
                else{
                    stack.pop();
                }
            }
            else if(a[0] == rows-1){//checking for bottom row
                if (!l.maze[rows-1][a[1]-1].getVisited() && !l.maze[rows-2][a[1]].getVisited() && !l.maze[rows-1][a[1]+1].getVisited()){
                    int x = rand.nextInt(3);
                    if(x == 0){
                        stack.push(new int[]{rows-1, a[1]-1});
                        l.maze[rows-1][a[1]-1].setVisited(true);
                        l.maze[rows-1][a[1]-1].setRight(false);
                    }
                    else if(x == 1){
                        stack.push(new int[]{rows-2, a[1]});
                        l.maze[rows-2][a[1]].setVisited(true);
                        l.maze[rows-2][a[1]].setBottom(false);
                    }
                    else{
                        stack.push(new int[]{rows-1, a[1]+1});
                        l.maze[rows-1][a[1]+1].setVisited(true);
                        l.maze[rows-1][a[1]].setRight(false);
                    }
                }
                else if(!l.maze[rows-1][a[1]-1].getVisited() && !l.maze[rows-2][a[1]].getVisited()){
                    int x = rand.nextInt(2);
                    if(x == 0){
                        stack.push(new int[]{rows-1, a[1]-1});
                        l.maze[rows-1][a[1]-1].setVisited(true);
                        l.maze[rows-1][a[1]-1].setRight(false);
                    }
                    else{
                        stack.push(new int[]{rows-2, a[1]});
                        l.maze[rows-2][a[1]].setVisited(true);
                        l.maze[rows-2][a[1]].setBottom(false);
                    }
                }
                else if(!l.maze[rows-1][a[1]-1].getVisited() && !l.maze[rows-1][a[1]+1].getVisited()){
                    int x = rand.nextInt(2);
                    if (x == 0){
                        stack.push(new int[]{rows-1, a[1]-1});
                        l.maze[rows-1][a[1]-1].setVisited(true);
                        l.maze[rows-1][a[1]-1].setRight(false);
                    }
                    else{
                        stack.push(new int[]{rows-1, a[1]+1});
                        l.maze[rows-1][a[1]+1].setVisited(true);
                        l.maze[rows-1][a[1]].setRight(false);
                    }
                }
                else if(!l.maze[rows-2][a[1]].getVisited() && !l.maze[rows-1][a[1]+1].getVisited()){
                    int x = rand.nextInt(2);
                    if(x == 0){
                        stack.push(new int[]{rows-2, a[1]});
                        l.maze[rows-2][a[1]].setVisited(true);
                        l.maze[rows-2][a[1]].setBottom(false);
                    }
                    else{
                        stack.push(new int[]{rows-1, a[1]+1});
                        l.maze[rows-1][a[1]+1].setVisited(true);
                        l.maze[rows-1][a[1]].setRight(false);
                    }
                }
                else if(!l.maze[rows-1][a[1]-1].getVisited()){
                    stack.push(new int[]{rows-1, a[1]-1});
                    l.maze[rows-1][a[1]-1].setVisited(true);
                    l.maze[rows-1][a[1]-1].setRight(false);
                }
                else if(!l.maze[rows-2][a[1]].getVisited()){
                    stack.push(new int[]{rows-2, a[1]});
                    l.maze[rows-2][a[1]].setVisited(true);
                    l.maze[rows-2][a[1]].setBottom(false);
                }
                else if(!l.maze[rows-1][a[1]+1].getVisited()){
                    stack.push(new int[]{rows-1, a[1]+1});
                    l.maze[rows-1][a[1]+1].setVisited(true);
                    l.maze[rows-1][a[1]].setRight(false);
                }
                else{
                    stack.pop();
                }
            }
            else{//else case for the cells that are not in any of the cases defined above so there are four neighbors for this case
                if(!l.maze[a[0]][a[1]-1].getVisited() && !l.maze[a[0]-1][a[1]].getVisited() && !l.maze[a[0]][a[1]+1].getVisited() && !l.maze[a[0]+1][a[1]].getVisited()){
                    int x = rand.nextInt(4);
                    if (x == 0){
                        stack.push(new int[]{a[0], a[1]-1});
                        l.maze[a[0]][a[1]-1].setVisited(true);
                        l.maze[a[0]][a[1]-1].setRight(false);
                    }
                    else if(x == 1){
                        stack.push(new int[]{a[0]-1, a[1]});
                        l.maze[a[0]-1][a[1]].setVisited(true);
                        l.maze[a[0]-1][a[1]].setBottom(false);
                    }
                    else if(x == 2){
                        stack.push(new int[]{a[0], a[1]+1});
                        l.maze[a[0]][a[1]+1].setVisited(true);
                        l.maze[a[0]][a[1]].setRight(false);
                    }
                    else{
                        stack.push(new int[]{a[0]+1, a[1]});
                        l.maze[a[0]+1][a[1]].setVisited(true);
                        l.maze[a[0]][a[1]].setBottom(false);
                    }
                }
                else if(!l.maze[a[0]][a[1]-1].getVisited() && !l.maze[a[0]-1][a[1]].getVisited() && !l.maze[a[0]][a[1]+1].getVisited()){
                    int x = rand.nextInt(3);
                    if (x == 0){
                        stack.push(new int[]{a[0], a[1]-1});
                        l.maze[a[0]][a[1]-1].setVisited(true);
                        l.maze[a[0]][a[1]-1].setRight(false);
                    }
                    else if(x == 1){
                        stack.push(new int[]{a[0]-1, a[1]});
                        l.maze[a[0]-1][a[1]].setVisited(true);
                        l.maze[a[0]-1][a[1]].setBottom(false);
                    }
                    else{
                        stack.push(new int[]{a[0], a[1]+1});
                        l.maze[a[0]][a[1]+1].setVisited(true);
                        l.maze[a[0]][a[1]].setRight(false);
                    }
                }
                else if(!l.maze[a[0]][a[1]-1].getVisited() && !l.maze[a[0]-1][a[1]].getVisited() && !l.maze[a[0]+1][a[1]].getVisited()){
                    int x = rand.nextInt(3);
                    if(x == 0){
                        stack.push(new int[]{a[0], a[1]-1});
                        l.maze[a[0]][a[1]-1].setVisited(true);
                        l.maze[a[0]][a[1]-1].setRight(false);
                    }
                    else if(x == 1){
                        stack.push(new int[]{a[0]-1, a[1]});
                        l.maze[a[0]-1][a[1]].setVisited(true);
                        l.maze[a[0]-1][a[1]].setBottom(false);
                    }
                    else{
                        stack.push(new int[]{a[0]+1, a[1]});
                        l.maze[a[0]+1][a[1]].setVisited(true);
                        l.maze[a[0]][a[1]].setBottom(false);
                    }
                }
                else if(!l.maze[a[0]-1][a[1]].getVisited() && !l.maze[a[0]][a[1]+1].getVisited() && !l.maze[a[0]+1][a[1]].getVisited()){
                    int x = rand.nextInt(3);
                    if(x == 0){
                        stack.push(new int[]{a[0]-1, a[1]});
                        l.maze[a[0]-1][a[1]].setVisited(true);
                        l.maze[a[0]-1][a[1]].setBottom(false);
                    }
                    else if(x == 1){
                        stack.push(new int[]{a[0], a[1]+1});
                        l.maze[a[0]][a[1]+1].setVisited(true);
                        l.maze[a[0]][a[1]].setRight(false);
                    }
                    else{
                        stack.push(new int[]{a[0]+1, a[1]});
                        l.maze[a[0]+1][a[1]].setVisited(true);
                        l.maze[a[0]][a[1]].setBottom(false);
                    }
                }
                else if(!l.maze[a[0]][a[1]-1].getVisited() && !l.maze[a[0]][a[1]+1].getVisited() && !l.maze[a[0]+1][a[1]].getVisited()){
                    int x = rand.nextInt(3);
                    if (x == 0){
                        stack.push(new int[]{a[0], a[1]-1});
                        l.maze[a[0]][a[1]-1].setVisited(true);
                        l.maze[a[0]][a[1]-1].setRight(false);
                    }
                    else if(x == 1){
                        stack.push(new int[]{a[0], a[1]+1});
                        l.maze[a[0]][a[1]+1].setVisited(true);
                        l.maze[a[0]][a[1]].setRight(false);
                    }
                    else {
                        stack.push(new int[]{a[0] + 1, a[1]});
                        l.maze[a[0] + 1][a[1]].setVisited(true);
                        l.maze[a[0]][a[1]].setBottom(false);
                    }
                }
                else if(!l.maze[a[0]][a[1]-1].getVisited() && !l.maze[a[0]-1][a[1]].getVisited()){
                    int x = rand.nextInt(2);
                    if (x == 0){
                        stack.push(new int[]{a[0], a[1]-1});
                        l.maze[a[0]][a[1]-1].setVisited(true);
                        l.maze[a[0]][a[1]-1].setRight(false);
                    }
                    else{
                        stack.push(new int[]{a[0]-1, a[1]});
                        l.maze[a[0]-1][a[1]].setVisited(true);
                        l.maze[a[0]-1][a[1]].setBottom(false);
                    }
                }
                else if(!l.maze[a[0]][a[1]-1].getVisited() && !l.maze[a[0]][a[1]+1].getVisited()){
                    int x = rand.nextInt(2);
                    if (x == 0){
                        stack.push(new int[]{a[0], a[1]-1});
                        l.maze[a[0]][a[1]-1].setVisited(true);
                        l.maze[a[0]][a[1]-1].setRight(false);
                    }
                    else{
                        stack.push(new int[]{a[0], a[1]+1});
                        l.maze[a[0]][a[1]+1].setVisited(true);
                        l.maze[a[0]][a[1]].setRight(false);
                    }
                }
                else if(!l.maze[a[0]][a[1]-1].getVisited() && !l.maze[a[0]+1][a[1]].getVisited()){
                    int x = rand.nextInt(2);
                    if (x == 0){
                        stack.push(new int[]{a[0], a[1]-1});
                        l.maze[a[0]][a[1]-1].setVisited(true);
                        l.maze[a[0]][a[1]-1].setRight(false);
                    }
                    else{
                        stack.push(new int[]{a[0]+1, a[1]});
                        l.maze[a[0]+1][a[1]].setVisited(true);
                        l.maze[a[0]][a[1]].setBottom(false);
                    }
                }
                else if(!l.maze[a[0]-1][a[1]].getVisited() && !l.maze[a[0]][a[1]+1].getVisited()){
                    int x = rand.nextInt(2);
                    if(x == 0){
                        stack.push(new int[]{a[0]-1, a[1]});
                        l.maze[a[0]-1][a[1]].setVisited(true);
                        l.maze[a[0]-1][a[1]].setBottom(false);
                    }
                    else{
                        stack.push(new int[]{a[0], a[1]+1});
                        l.maze[a[0]][a[1]+1].setVisited(true);
                        l.maze[a[0]][a[1]].setRight(false);
                    }
                }
                else if(!l.maze[a[0]-1][a[1]].getVisited() && !l.maze[a[0]+1][a[1]].getVisited()){
                    int x = rand.nextInt(2);
                    if(x == 0){
                        stack.push(new int[]{a[0]-1, a[1]});
                        l.maze[a[0]-1][a[1]].setVisited(true);
                        l.maze[a[0]-1][a[1]].setBottom(false);
                    }
                    else{
                        stack.push(new int[]{a[0]+1, a[1]});
                        l.maze[a[0]+1][a[1]].setVisited(true);
                        l.maze[a[0]][a[1]].setBottom(false);
                    }
                }
                else if(!l.maze[a[0]][a[1]+1].getVisited() && !l.maze[a[0]+1][a[1]].getVisited()){
                    int x = rand.nextInt(2);
                    if(x == 0){
                        stack.push(new int[]{a[0], a[1]+1});
                        l.maze[a[0]][a[1]+1].setVisited(true);
                        l.maze[a[0]][a[1]].setRight(false);
                    }
                    else{
                        stack.push(new int[]{a[0]+1, a[1]});
                        l.maze[a[0]+1][a[1]].setVisited(true);
                        l.maze[a[0]][a[1]].setBottom(false);
                    }
                }
                else if(!l.maze[a[0]][a[1]-1].getVisited()){
                    stack.push(new int[]{a[0], a[1]-1});
                    l.maze[a[0]][a[1]-1].setVisited(true);
                    l.maze[a[0]][a[1]-1].setRight(false);
                }
                else if(!l.maze[a[0]-1][a[1]].getVisited()){
                    stack.push(new int[]{a[0]-1, a[1]});
                    l.maze[a[0]-1][a[1]].setVisited(true);
                    l.maze[a[0]-1][a[1]].setBottom(false);
                }
                else if(!l.maze[a[0]][a[1]+1].getVisited()){
                    stack.push(new int[]{a[0], a[1]+1});
                    l.maze[a[0]][a[1]+1].setVisited(true);
                    l.maze[a[0]][a[1]].setRight(false);
                }
                else if(!l.maze[a[0]+1][a[1]].getVisited()){
                    stack.push(new int[]{a[0]+1, a[1]});
                    l.maze[a[0]+1][a[1]].setVisited(true);
                    l.maze[a[0]][a[1]].setBottom(false);
                }
                else{
                    stack.pop();
                }
            }
        }
        l.maze[rows-1][cols-1].setRight(false);//makes sure that there is an exit for the end of the maze
        for(int i = 0; i<rows; i++){
            for(int j = 0; j<cols; j++){
                l.maze[i][j].setVisited(false);//setting the visited to false in every cell
            }
        }
        return l;
    }
    /* TODO: Print a representation of the maze to the terminal */
    public void printMaze(boolean path) {
        String line = "";
        for(int i = 0; i<maze[0].length; i++){
            line += "| - - - ";//adding the top row
        }
        line+="|";
        for(int i = 0; i<maze.length; i++){
            line+="\n";
            if(i!=0) {
                line += "|";
            }
            else{
                line+=" ";
            }
            for(int j = 0; j<maze[i].length; j++){//adding sidebars or whatever include the .getRight() attribute
                if(maze[i][j].getRight()){
                    if(path){
                        if(maze[i][j].getVisited()) {
                            line += "   *   |";
                        }
                        else{
                            line += "       |";
                        }
                    }
                    else{
                        line += "       |";
                    }
                }
                else{
                    if(path){
                        if(maze[i][j].getVisited()){
                            line+= "   *    ";
                        }
                        else{
                            line+= "        ";
                        }
                    }
                    else{
                        line+= "        ";
                    }
                }
            }
            line+="\n";
            for(int j = 0; j<maze[i].length; j++){//adding bottom walls if their .getBottom() is true
                if(maze[i][j].getBottom()){
                    line+="| - - - ";
                }
                else{
                    line+="|       ";
                }
            }
            line+="|";
        }
        System.out.println(line);
    }
    /* TODO: Solve the maze using the algorithm found in the writeup. */
    public void solveMaze(){
        Q1Gen<int[]> q = new Q1Gen<>();//creating a queue
        q.add(new int[]{0,0});//adding the first set of points as 0,0
        while(!q.isEmpty()){//runs until queue is empty
            int[] top = q.remove();//always remove the top of the queue since that has been visited
            maze[top[0]][top[1]].setVisited(true);//set the visited attribute of the top of the queue to true
            if(top[0] == maze.length-1 && top[1] == maze[0].length-1){//checking to see if we reached the end of the maze
                break;
            }
            if (top[0]==0 && top[1]==0) {//checking top left corner
                if (!maze[top[0]][0].getRight() && !maze[top[0]][top[1] + 1].getVisited()) {
                    q.add(new int[]{top[0], top[1] + 1});
                }
                if (!maze[top[0]][top[1]].getBottom() && !maze[top[0] + 1][top[1]].getVisited()) {
                    q.add(new int[]{top[0] + 1, top[1]});
                }
            }
            else if(top[0]==0 && top[1]==maze[0].length-1){//checking top right corner
                if(!maze[0][top[1]-1].getRight() && !maze[0][top[1]-1].getVisited()){
                    q.add(new int[]{0, top[1]-1});
                }
                if(!maze[0][top[1]].getBottom() && !maze[1][top[1]].getVisited()){
                    q.add(new int[]{1, top[1]});
                }
            }
            else if(top[0]==maze.length-1 && top[1]==0){//checking bottom left corner
                if(!maze[top[0]-1][0].getBottom() && !maze[top[0]-1][0].getVisited()){
                    q.add(new int[]{top[0]-1, 0});
                }
                if(!maze[top[0]][top[1]+1].getVisited() && !maze[top[0]][top[1]].getRight()){
                    q.add(new int[]{top[0], top[1]+1});
                }
            }
            else if(top[0]==0){//checking top row
                if(!maze[0][top[1]-1].getRight() && !maze[0][top[1]-1].getVisited()){
                    q.add(new int[]{0, top[1]-1});
                }
                if(!maze[0][top[1]+1].getVisited() && !maze[0][top[1]].getRight()){
                    q.add(new int[]{0, top[1]+1});
                }
                if(!maze[1][top[1]].getVisited() && !maze[0][top[1]].getBottom()){
                    q.add(new int[]{1, top[1]});
                }
            }
            else if(top[1]==0){//checking left column
                if(!maze[top[0]-1][0].getVisited() && !maze[top[0]-1][0].getBottom()){
                    q.add(new int[]{top[0]-1, 0});
                }
                if(!maze[top[0]][1].getVisited() && !maze[top[0]][0].getRight()){
                    q.add(new int[]{top[0], 1});
                }
                if(!maze[top[0]+1][0].getVisited() && !maze[top[0]][0].getBottom()){
                    q.add(new int[]{top[0]+1, 0});
                }
            }
            else if(top[0]==maze.length-1){//checking bottom row
                if(!maze[top[0]][top[1]-1].getVisited() && !maze[top[0]][top[1]-1].getRight()){
                    q.add(new int[]{top[0], top[1]-1});
                }
                if(!maze[top[0]-1][top[1]].getVisited() && !maze[top[0]-1][top[1]].getBottom()){
                    q.add(new int[]{top[0]-1, top[1]});
                }
                if(!maze[top[0]][top[1]+1].getVisited() && !maze[top[0]][top[1]].getRight()){
                    q.add(new int[]{top[0], top[1]+1});
                }
            }
            else if(top[1]==maze[0].length-1){//checking right column
                if(!maze[top[0]-1][top[1]].getVisited() && !maze[top[0]-1][top[1]].getBottom()){
                    q.add(new int[]{top[0]-1, top[1]});
                }
                if(!maze[top[0]][top[1]-1].getVisited() && !maze[top[0]][top[1]-1].getRight()){
                    q.add(new int[]{top[0], top[1]-1});
                }
                if(!maze[top[0]+1][top[1]].getVisited() && !maze[top[0]][top[1]].getBottom()){
                    q.add(new int[]{top[0]+1, top[1]});
                }
            }
            else{//this case has all four neighbors
                if(!maze[top[0]][top[1]-1].getVisited() && !maze[top[0]][top[1]-1].getRight()){
                    q.add(new int[]{top[0], top[1]-1});
                }
                if(!maze[top[0]-1][top[1]].getVisited() && !maze[top[0]-1][top[1]].getBottom()){
                    q.add(new int[]{top[0]-1, top[1]});
                }
                if(!maze[top[0]][top[1]+1].getVisited() && !maze[top[0]][top[1]].getRight()){
                    q.add(new int[]{top[0], top[1]+1});
                }
                if(!maze[top[0]+1][top[1]].getVisited() && !maze[top[0]][top[1]].getBottom()){
                    q.add(new int[]{top[0]+1, top[1]});
                }
            }
        }
        printMaze(true);
    }
    public static void main(String[] args){
        MyMaze x = makeMaze(5,10);
        x.printMaze(true);
        System.out.println("Solved Maze");
        x.solveMaze();
    }
}
